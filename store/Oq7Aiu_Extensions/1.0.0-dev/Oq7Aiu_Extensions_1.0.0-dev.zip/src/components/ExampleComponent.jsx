import React from 'react';

const ExampleComponent = ({ text = 'Hello from ExampleComponent' }) => {
  return (
    <div style={{ padding: 16, border: '1px solid #ddd', borderRadius: 6 }}>
      <h3 style={{ margin: '0 0 8px 0' }}>Example Component</h3>
      <p style={{ margin: 0 }}>{text}</p>
    </div>
  );
};

export default ExampleComponent;
