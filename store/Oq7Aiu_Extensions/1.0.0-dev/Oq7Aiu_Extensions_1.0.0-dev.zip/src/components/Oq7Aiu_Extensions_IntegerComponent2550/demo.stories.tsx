/* eslint-disable react/jsx-no-useless-fragment */
import type { Meta, StoryObj } from '@storybook/react';

import { stateProps, configProps, fieldMetadata } from './mock';

import Oq7AiuExtensionsIntegerComponent2550 from './index';

const meta: Meta<typeof Oq7AiuExtensionsIntegerComponent2550> = {
  title: 'Oq7AiuExtensionsIntegerComponent2550',
  component: Oq7AiuExtensionsIntegerComponent2550,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof Oq7AiuExtensionsIntegerComponent2550>;

export const BaseOq7AiuExtensionsIntegerComponent2550: Story = (args: any) => {

  const props = {
    value: configProps.value,
    hasSuggestions: configProps.hasSuggestions,
    fieldMetadata,
    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: () => {/* nothing */},
            triggerFieldChange: () => {/* nothing */}
          };
        },
        ignoreSuggestion: () => {/* nothing */},
        acceptSuggestion: () => {/* nothing */},
        setInheritedProps: () => {/* nothing */},
        resolveConfigProps: () => {/* nothing */}
      };
    }
  };

  return (
    <>
      <Oq7AiuExtensionsIntegerComponent2550 {...props} {...args} />
    </>
  );
};

BaseOq7AiuExtensionsIntegerComponent2550.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  showGroupSeparators: configProps.showGroupSeparators,
  testId: configProps.testId,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  required: configProps.required,
  status: configProps.status,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  variant: configProps.variant,
  validatemessage: configProps.validatemessage,
  min: configProps.min,
  max: configProps.max
};
