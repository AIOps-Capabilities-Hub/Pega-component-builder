export const configProps = {
  value: '',
  label: 'Integer Component 25-50',
  showGroupSeparators: true,
  helperText: 'Enter a value between 25 and 50',
  testId: 'integer-12345678',
  hasSuggestions: false,
  displayMode: '',
  hideLabel: false,
  readOnly: false,
  required: false,
  disabled: false,
  status: '',
  validatemessage: 'Integer component with min value 25 and max value 50',
  placeholder: '25',
  variant: '',
  min: 25,
  max: 50
};

export const stateProps = {
  value: '.IntegerSample',
  hasSuggestions: false
};

export const fieldMetadata = {
  classID: 'DIXL-MediaCo-Work-NewService',
  type: 'Integer',
  displayAs: 'pxInteger',
  label: 'Integer sample'
};
