import React from 'react';
import ExampleComponent from './ExampleComponent';

export default {
  title: 'Demo/ExampleComponent',
  component: ExampleComponent
};

export const Default = () => <ExampleComponent text="This is a demo story" />;
