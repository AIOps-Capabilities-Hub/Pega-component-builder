import { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';

const IntegerField = ({ value: propValue, onChange, min, max, label, required, placeholder }) => {
  const [value, setValue] = useState(propValue ?? '');
  const [error, setError] = useState('');

  const validate = useCallback(
    val => {
      if (val === '' || val === null || val === undefined) {
        if (required) {
          setError('Value is required');
          return false;
        }
        setError('');
        return true;
      }

      const intVal = parseInt(val, 10);
      if (Number.isNaN(intVal)) {
        setError('Must be an integer');
        return false;
      }

      if (min !== undefined && intVal < min) {
        setError(`Minimum value is ${min}`);
        return false;
      }

      if (max !== undefined && intVal > max) {
        setError(`Maximum value is ${max}`);
        return false;
      }

      setError('');
      return true;
    },
    [min, max, required]
  );

  useEffect(() => {
    setValue(propValue ?? '');
    validate(propValue ?? '');
  }, [propValue, validate]);

  const handleChange = e => {
    const next = e.target.value;
    // allow empty string while editing
    setValue(next);
    const ok = validate(next);
    if (ok && onChange) {
      onChange(next === '' ? '' : parseInt(next, 10));
    } else if (onChange) {
      // propagate raw value so parent can decide
      onChange(next);
    }
  };

  const handleBlur = () => {
    if (value === '' || value === null) return;
    let intVal = parseInt(value, 10);
    if (Number.isNaN(intVal)) {
      setValue('');
      if (onChange) onChange('');
      validate('');
      return;
    }
    if (min !== undefined && intVal < min) intVal = min;
    if (max !== undefined && intVal > max) intVal = max;
    setValue(String(intVal));
    if (onChange) onChange(intVal);
    validate(intVal);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && (
        <label style={{ fontSize: 13, fontWeight: 600 }}>
          {label} {required ? '*' : ''}
        </label>
      )}
      <input
        type="number"
        step={1}
        value={value}
        onChange={handleChange}
        onBlur={handleBlur}
        min={min}
        max={max}
        placeholder={placeholder}
        style={{ padding: '8px 10px', borderRadius: 4, border: error ? '1px solid #d32f2f' : '1px solid #ccc' }}
      />
      {error && <div style={{ color: '#d32f2f', fontSize: 12 }}>{error}</div>}
    </div>
  );
};

IntegerField.propTypes = {
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  onChange: PropTypes.func,
  min: PropTypes.number,
  max: PropTypes.number,
  label: PropTypes.string,
  required: PropTypes.bool,
  placeholder: PropTypes.string
};

IntegerField.defaultProps = {
  value: '',
  onChange: undefined,
  min: 20,
  max: 80,
  label: undefined,
  required: false,
  placeholder: ''
};

export default IntegerField;
