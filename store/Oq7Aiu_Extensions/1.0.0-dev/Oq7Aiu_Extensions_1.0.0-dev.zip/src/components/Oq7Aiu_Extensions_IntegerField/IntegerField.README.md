IntegerField
============

Description
-----------
A simple integer input React component with client-side min/max validation and optional required check. Designed to be published to Pega as a custom DX component.

Publishing to Pega (summary)
----------------------------
1. Ensure you're authenticated with the DX Component Builder CLI for this project (the repo provides `custom-dx-components` in `dxcomponentdemo`):

   npm run authenticate

2. Build/validate the component (from the `dxcomponentdemo` folder):

   npm run validate

3. Publish the component to your Constellation/Pega server:

   npm run publish

Pega property configuration
--------------------------
On the Pega side, configure the property that will store the value as an Integer data type. The component will pass integer values (Number) when the input is valid; otherwise it may pass an empty string while the user is editing invalid input.

Default min/max values
----------------------
This component now defaults to a minimum value of 20 and a maximum value of 80 when `min` and `max` props are not provided. You can still override these by passing `min` and `max` explicitly to the component.

Notes
-----
- The DX component tooling often expects components to be exported from `src/components` and picks up metadata from the project configuration (`tasks.config.json`). Ensure `tasks.config.json` `components-directory-path` points to `src/components` (it does by default in this demo).
- For more detailed publishing options (library vs component mode, ruleset/version, server), consult `tasks.config.json` and the project's README.
