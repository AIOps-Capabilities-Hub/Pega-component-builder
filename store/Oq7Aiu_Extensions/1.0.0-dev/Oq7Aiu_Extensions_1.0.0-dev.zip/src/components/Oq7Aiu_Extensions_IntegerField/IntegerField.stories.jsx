import { useState } from 'react';
import IntegerField from './index';

export default {
  title: 'Extensions/IntegerField',
  component: IntegerField,
  parameters: {
    docs: {
      description: {
        component:
          'A simple integer input with min/max validation. When publishing to Pega, export this component and configure the property as an integer in the Pega rule that references the component.'
      }
    }
  }
};

export const Playground = () => {
  const [val, setVal] = useState(30);
  return (
    <div style={{ width: 320 }}>
      <IntegerField label="Quantity" value={val} onChange={v => setVal(v)} required placeholder="Enter an integer" />
      <div style={{ marginTop: 12 }}>Current value: {String(val)}</div>
    </div>
  );
};

// export const InvalidExample = () => {
//   const [val, setVal] = useState('');
//   return (
//     <div style={{ width: 320 }}>
//       <IntegerField label="Age" value={val} onChange={v => setVal(v)} required placeholder="Enter your age" />
//       <div style={{ marginTop: 12 }}>Current value: {String(val)}</div>
//     </div>
//   );
// };

// export const WithDefaults = () => {
//   const [val, setVal] = useState(25);
//   return (
//     <div style={{ width: 320 }}>
//       <IntegerField label="Quantity (explicit props)" value={val} onChange={v => setVal(v)} min={20} max={80} required placeholder="Enter an integer" />
//       <div style={{ marginTop: 12 }}>Current value: {String(val)}</div>
//       <div style={{ marginTop: 8, fontSize: 12, color: '#666' }}>This story passes min=20 and max=80 explicitly.</div>
//     </div>
//   );
// };

// export const UsingProjectDefaults = () => {
//   const [val, setVal] = useState(25);
//   return (
//     <div style={{ width: 320 }}>
//       <IntegerField label="Quantity (using defaults)" value={val} onChange={v => setVal(v)} required placeholder="Enter an integer" />
//       <div style={{ marginTop: 12 }}>Current value: {String(val)}</div>
//       <div style={{ marginTop: 8, fontSize: 12, color: '#666' }}>This story uses min=20 and max=80 from defaultProps.</div>
//     </div>
//   );
// };
