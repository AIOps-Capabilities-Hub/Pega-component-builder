
/* eslint-disable react/jsx-no-useless-fragment */
import type { Meta, StoryObj } from '@storybook/react';

import Oq7AiuExtensionsDemoComponentPega from './index';

import { stateProps, fieldMetadata, configProps } from './mock';

const meta: Meta<typeof Oq7AiuExtensionsDemoComponentPega> = {
  title: 'Oq7AiuExtensionsDemoComponentPega',
  component: Oq7AiuExtensionsDemoComponentPega,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof Oq7AiuExtensionsDemoComponentPega>;

export const BaseOq7AiuExtensionsDemoComponentPega: Story = (args: any) => {

  const props = {
    value: configProps.value,
    hasSuggestions: configProps.hasSuggestions,
    fieldMetadata,
    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: () => {/* nothing */},
            triggerFieldChange: () => {/* nothing */}
          };
        },
        ignoreSuggestion: () => {/* nothing */},
        acceptSuggestion: () => {/* nothing */},
        setInheritedProps: () => {/* nothing */},
        resolveConfigProps: () => {/* nothing */}
      };
    }
  };

  return (
    <>
      <Oq7AiuExtensionsDemoComponentPega {...props} {...args} />
    </>
  );
};

BaseOq7AiuExtensionsDemoComponentPega.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  testId: configProps.testId,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  required: configProps.required,
  status: configProps.status,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  variant: configProps.variant,
  validateMessage: configProps.validateMessage
};
